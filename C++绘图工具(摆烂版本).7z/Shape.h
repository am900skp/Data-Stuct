﻿#ifndef  _SHAPE_H_
#define _SHAPE_H_
#include<easyx.h>
//绘制的图形有哪些，枚举
enum ShapeType
{
	ST_Line,		//线
	ST_Rect,		//矩形
	ST_Ellipse,		//圆
	ST_Graffiti,	//涂鸦
	ST_FiveStar,	//五角星
	ST_Max
};

/* @形状*/
struct Shape
{
	int type;			//形状类型
	COLORREF lineColor;	//线条颜色
};
//初始化形状的成员
void shape_init(Shape* shape, int type, COLORREF c);

/* @直线*/
struct Line
{
	Shape super;	//组合一个形状结构(相当父类)
	int x1;
	int y1;
	int x2;
	int y2;
};

void line_init(Line* pline, int x1, int y1, int x2, int y2,COLORREF c);

void line_draw(Line* pline);

void line_write(Line* pline, FILE* fp);

/* @矩形*/
struct Rect
{
	Line super;
};

void rect_init(Rect* rect, int x1, int y1, int x2, int y2, COLORREF c);

void rect_draw(Rect* rect);

void rect_write(Rect* rect, FILE* fp);


/* @涂鸦*/
struct Graffiti
{
	Shape super;	//必须是第一个成员
	POINT* points;	//数组指针
	int size;		//当前点数
	int capacity;	//容量
};

void graf_init(Graffiti* graf, COLORREF c);

void graf_draw(Graffiti* graf);

void graf_addPoint(Graffiti* graf, int x, int y);

void graf_free(Graffiti* graf);

void graf_write(Graffiti* graf, FILE* fp);


#endif // ! _SHAPE_H_

