﻿#pragma once
#include<easyx.h>

enum ButtonType
{
	BT_Rect,
	BT_Circle
};

struct Button
{
	int type;				//按钮形状
	int x;
	int y;
	int w;
	int h;
	COLORREF bkColor;		//背景颜色
	COLORREF borderColor;	//边框颜色
	char text[50];			//按钮文本

	COLORREF hoverColor;	//鼠标悬停颜色
	COLORREF curColor;		//当前背景颜色

	void (*onClicked)();	//按钮被点击的时候，自动调用的函数，由用户实现
};

//在堆区创建一个按钮
Button* createButton(int x, int y, int w, int h, int type);
//绘制按钮
void btn_draw(Button* btn);
//鼠标是否在按钮上
bool btn_isIn(Button* btn, ExMessage* msg);
//鼠标左键是否按下
bool btn_isClicked(Button* btn, ExMessage* msg);


//设置文本
void btn_setText(Button* btn, const char* text);

//按钮的消息处理函数
void btn_msgHanding(Button*bnt,ExMessage* msg);

