﻿#include "Button.h"

Button* createButton(int x, int y, int w, int h, int type)
{
    Button* btn = (Button*)calloc(1, sizeof(Button));
    if (!btn)
        return NULL;
    btn->x = x;
    btn-> y = y;
    btn->w = w;
    btn->h = h;
    btn->type = type;
    btn->bkColor = RGB(230, 231, 232);
    btn->borderColor = RGB(50, 124, 46);
    memset(btn->text, 0, sizeof(btn->text));
    setbkmode(TRANSPARENT);


    btn->hoverColor = RGB(85, 85, 85);
    btn->curColor = btn->bkColor;

    btn->onClicked = NULL;

    return btn;
}

void btn_draw(Button* btn)
{
    setlinecolor(btn->borderColor);
    setfillcolor(btn->curColor);
    if (btn->type == BT_Circle)
    {
        fillellipse(btn->x, btn->y, btn->x + btn->w, btn->y + btn->h);
    }
    else if (btn->type == BT_Rect)
    {
        fillroundrect(btn->x, btn->y, btn->x + btn->w, btn->y + btn->h,5,5);
    }
    //绘制文本
    if (btn->text[0] != '\0')
    {
        settextcolor(RED);

        int hspace = (btn->w - textwidth(btn->text)) / 2;
        int vspace = (btn->h - textheight(btn->text)) / 2;

        outtextxy(btn->x + hspace, btn->y+vspace, btn->text);
    }
}

bool btn_isIn(Button* btn, ExMessage* msg)
{
    if (msg->x > btn->x && msg->x<btn->x + btn->w && msg->y>btn->y && msg->y < btn->y + btn->h)
    {
        return true;
    }
    return false;
}

bool btn_isClicked(Button* btn, ExMessage* msg)
{
    if (btn_isIn(btn, msg) && msg->message == WM_LBUTTONDOWN)
    {
        if(btn->onClicked)
            btn->onClicked();
        return true;
    }
    return false;
}

void btn_setText(Button* btn, const char* text)
{
    strcpy(btn->text, text);
}

void btn_msgHanding(Button* btn, ExMessage*msg)
{
    if (btn_isIn(btn, msg))
    {
        btn->curColor = btn->hoverColor;
    }
    else
    {
        btn->curColor = btn->bkColor;
    }
}
