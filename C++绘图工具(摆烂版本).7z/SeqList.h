﻿#pragma once
/* @宏顺序表*/
struct SeqList
{
	void** base;		//指向动态分配的数组
	int size;		//当前元素个数
	int capacity;	//最大容量
};

#define SeqList_Init(plist) plist.capacity = 10;plist.size = 0;\
plist.base = (void**)calloc(plist.capacity,sizeof(void*));\
if(!plist.base) {printf("memory allocated failed~");}
#define SeqList_Add(plist,pval) \
if(plist.size < plist.capacity) \
{\
	plist.base[plist.size++] = pval;\
}
#define SeqList_Foreach(pvar,plist) \
for(int i =0,cnt = 0;i<plist.size;i++,cnt = 0)\
for(pvar = plist.base[i];cnt<1;cnt++)
