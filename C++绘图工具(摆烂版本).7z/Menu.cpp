﻿#include "Menu.h"
#include"Button.h"
#include<malloc.h>
#include<string.h>
#include<stdio.h>
#include<easyx.h>
static void menu_drawActions(Menu* menu);
Menu* createMenu(int x, int y, const char* text)
{
	Menu* menu = (Menu*)calloc(1, sizeof(Menu));
	if (!menu)
		return NULL;
	menu->x = x;
	menu->y = y;
	menu->w = 60;
	menu->h = 20;
	strcpy(menu->text, text);
	SeqList_Init(menu->actions);

	menu->onClicked = NULL;
	menu->isDown = false;

	return menu;
}

void menu_draw(Menu* menu)
{
	setfillcolor(RGB(230, 231, 232));
	fillrectangle(menu->x, menu->y, menu->x + menu->w, menu->y + menu->h);
	//绘制文本
	if (menu->text[0] != '\0')
	{
		settextcolor(RED);

		int hspace = (menu->w - textwidth(menu->text)) / 2;
		int vspace = (menu->h - textheight(menu->text)) / 2;

		outtextxy(menu->x + hspace, menu->y + vspace, menu->text);
	}

	menu_drawActions(menu);
}

static bool isIn(Menu* menu, ExMessage* msg)
{
	if (msg->x > menu->x && msg->x<menu->x + menu->w && msg->y>menu->y && msg->y < menu->h)
	{
		return true;
	}
	return false;
}

void menu_handingMsg(Menu* menu, ExMessage* msg)
{
	if (menu->isDown)
	{
		SeqList_Foreach(void* act, menu->actions)
		{
			Button* btn = (Button*)act;
			btn_msgHanding(btn, msg);
			if (btn_isClicked(btn, msg) && menu->onClicked != NULL)
			{
				menu->onClicked(i, btn->text);
			}
		}
	}

	//判断鼠标是否在菜单上卖弄点击了一下
	if (msg->message == WM_LBUTTONDOWN && isIn(menu,msg))
	{
		menu->isDown = true;
		printf("%s 被点击\n", menu->text);
	}
	else  if(msg->message == WM_LBUTTONDOWN)//只要不是点击菜单，这个就会执行，isDown就是false
	{
		cleardevice();
		printf("temp = false\n");
		menu->isDown = false;
	}
}

void menu_addAction(Menu* menu, const char* text)
{
	int totalH = menu->h + menu->actions.size * 20;
	Button* btn = createButton(menu->x, menu->y + totalH, 150, 20, BT_Rect);
	btn_setText(btn, text);
	SeqList_Add(menu->actions, btn);
}

static void menu_drawActions(Menu* menu)
{
	if (menu->isDown)
	{
		SeqList_Foreach(void* act, menu->actions)
		{
			Button* btn = (Button*)act;
			btn_draw(btn);
		}
	}
}
