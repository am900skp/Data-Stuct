﻿#pragma once
#include"SeqList.h"

struct ExMessage;
/* @菜单*/
struct Menu
{
	int x;
	int y;
	int w;
	int h;
	char text[20];	  //文本
	SeqList actions;  //有很多的项

	void (*onClicked)(int id,const char*text);	//按钮被点击了调用的函数
	bool isDown;	//鼠标左键是否按下
};

//创建菜单
Menu* createMenu(int x, int y, const char* text);

void menu_draw(Menu* menu);

//菜单的消息处理
void menu_handingMsg(Menu* menu, ExMessage* msg);

//添加动作
void menu_addAction(Menu* menu, const char* text);

