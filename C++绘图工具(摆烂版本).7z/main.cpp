﻿#include<stdio.h>
#include"Shape.h"
#include"Button.h"
#include"Menu.h"


void saveToFile(const char* filename);
void readFromFile(const char* filename);

//顺序表来存储所有的形状 Line  Rect ...
struct ShapeSet
{
	void* shapes[256];		//万能指针数组,所有类型的指针都可以自动转换为void*
	int size;
};
#define ShapeSet_Init(set) memset(set.shapes,0,sizeof(set.shapes));set.size = 0
#define ShapeSet_Add(set,pshape) set.shapes[set.size++] = pshape
#define ShapeSet_Pop(set) if(set.size>0){free(set.shapes[set.size-1]);set.size--;}
//快捷遍历顺序表
#define ShapeSet_Foreach(pval,set) \
for(int i = 0,cnt = 0;i < set.size;++i,cnt = 0) \
for(pval = set.shapes[i];cnt < 1;++cnt)


ShapeSet g_shapes;
POINT begPos = { 0,0 };		//鼠标点击的位置
bool isPress = false;		//鼠标左键是否按下

int curShapeType = ST_Rect;		//当前绘图的形状
COLORREF curLineColor = RED;	//当前的线条颜色
Graffiti g_graf;				//用于当前操作的涂鸦

void onMouseLButtonDown(ExMessage* msg)
{
	//记录开始点击的坐标
	begPos = { msg->x,msg->y };
	//左键按下了
	isPress = true;

	if (curShapeType == ST_Graffiti)
	{
		graf_init(&g_graf, curLineColor);
		graf_addPoint(&g_graf, msg->x, msg->y);
	}
}

void onMouseLButtonUp(ExMessage* msg)
{
	//放开的时候保存线
	isPress = false;

	//如果是误操作就丢弃(很小)
	if (abs(begPos.x - msg->x) <= 2 && abs(begPos.y - msg->y) <= 2 && curShapeType != ST_Graffiti)
	{
		return;
	}

	//
	if (g_graf.size <= 2 && curShapeType == ST_Graffiti)
	{
		return;
	}

	//动态申请一个内存，存放形状
	if (curShapeType == ST_Line)
	{
		Line* le = (Line*)calloc(1, sizeof(Line));
		line_init(le, begPos.x, begPos.y, msg->x, msg->y, curLineColor);
		ShapeSet_Add(g_shapes, le);
	}
	else if (curShapeType == ST_Rect)
	{
		Rect* rect = (Rect*)calloc(1, sizeof(Rect));
		rect_init(rect, begPos.x, begPos.y, msg->x, msg->y, curLineColor);
		ShapeSet_Add(g_shapes, rect);
	}
	else if (curShapeType == ST_Graffiti)
	{
		Graffiti* g = (Graffiti*)calloc(1, sizeof(Graffiti));
		*g = g_graf;		//把刚才绘制的涂鸦，交给申请的内存
		ShapeSet_Add(g_shapes, g);
	}

}

void onMouseMove(ExMessage* msg)
{
	if (isPress)
	{
		cleardevice();
		setlinecolor(curLineColor);
		switch (curShapeType)
		{
		case ST_Line:
			line(begPos.x, begPos.y, msg->x, msg->y);
			break;
		case ST_Rect:
			rectangle(begPos.x, begPos.y, msg->x, msg->y);
			break;
		case ST_Graffiti:
			graf_addPoint(&g_graf, msg->x, msg->y);
			graf_draw(&g_graf);
			break;
		}
	}
}

void onMouseRButtonDown(ExMessage*msg)
{
	printf("onMouseRButtonDown  %d\n",g_shapes.size);
	ShapeSet_Pop(g_shapes);
	cleardevice();		//撤销一个清屏一下
}

void btn_onClicked()
{
	printf("btn_onClicked\n");
}

void on_menuClicked(int id, const char* text)
{
	curShapeType = id;
	printf("on_menuClicked %d  %s\n",id,text);
}

void on_fileMenuClicked(int id, const char* text)
{
	if (strcmp(text, "打开") == 0)
	{
		readFromFile("maye.txt");
	}
	else if (strcmp(text, "保存") == 0)
	{
		saveToFile("maye.txt");
	}
}

int main()
{
	initgraph(640, 480,EW_SHOWCONSOLE);
	//设置窗口背景颜色
	setbkcolor(WHITE);
	cleardevice();

	ShapeSet_Init(g_shapes);

	Button* btn = createButton(0, 300, 150, 30, BT_Rect);
	btn_setText(btn, "Maye");
	btn->onClicked = btn_onClicked;

	Menu* menu = createMenu(0, 0, "形状");
	menu_addAction(menu, "Line");
	menu_addAction(menu, "Rect");
	menu_addAction(menu, "Ellipse");
	menu_addAction(menu, "Graffiti");
	menu_addAction(menu, "FiveStar");
	menu->onClicked = on_menuClicked;

	Menu* fileMenu = createMenu(menu->x + menu->w, menu->y, "文件");
	menu_addAction(fileMenu, "打开");
	menu_addAction(fileMenu, "保存");
	fileMenu->onClicked = on_fileMenuClicked;

	//通过鼠标绘制，获取鼠标的消息
	while (true)
	{
		//双缓冲
		BeginBatchDraw();

		//绘制所有形状
		ShapeSet_Foreach(void* shape, g_shapes)
		{
			int type = ((Shape*)shape)->type;
			switch (type)
			{
			case ST_Line:
				line_draw((Line*)shape);
				break;
			case ST_Rect:
				rect_draw((Rect*)shape);
				break;
			case ST_Graffiti:
				graf_draw((Graffiti*)shape);
				break;
			}		
		}

		//绘制控件
		btn_draw(btn);
		menu_draw(menu);
		menu_draw(fileMenu);

		EndBatchDraw();	//结束双缓冲

		//定义一个消息的结构体
		ExMessage msg;
		//不断地获取消息
		while (peekmessage(&msg, EM_MOUSE))
		{
			if (btn_isClicked(btn, &msg))
			{
				curLineColor = RGB(187, 136, 243);
				printf("btn_isClicked\n");
			}
			btn_msgHanding(btn, &msg);
			menu_handingMsg(menu, &msg);
			menu_handingMsg(fileMenu, &msg);

			switch (msg.message)
			{
			case WM_LBUTTONDOWN:	//左键按下
				onMouseLButtonDown(&msg);
				break;
			case WM_MOUSEMOVE:		//鼠标移动
				onMouseMove(&msg);
				break;
			case WM_LBUTTONUP:		//左键释放
				onMouseLButtonUp(&msg);
				break;
			case WM_RBUTTONDOWN:
				onMouseRButtonDown(&msg);
				break;
			case WM_MOUSEWHEEL:
				curShapeType = (curShapeType + 1) % ST_Max;
				break;
			default:
				break;
			}
		}
	}


	return 0;
}

/*
* 1，选择形状和颜色的菜单(封装菜单)
* 2，保存图形和加载图形(文件操作)
* 3，按钮的处理之回调写法
*/


void saveToFile(const char* filename)
{
	FILE* fp = fopen(filename, "w");
	if (!fp)
		return;

	//遍历g_shapes，保存每个形状
	ShapeSet_Foreach(void* shape, g_shapes)
	{
		switch (((Shape*)shape)->type)
		{
		case ST_Line:
			line_write((Line*)shape,fp);
			break;
		case ST_Rect:
			rect_write((Rect*)shape, fp);
			break;
		case ST_Ellipse:
			break;
		case ST_Graffiti:
			graf_write((Graffiti*)shape, fp);
			break;
		case ST_FiveStar:
			break;
		case ST_Max:
			break;
		default:
			break;
		}
	}

	fclose(fp);
}

void readFromFile(const char* filename)
{
	FILE* fp = fopen(filename, "r");
	if (!fp)
		return;

	while (!feof(fp))
	{
		//1，获取类型
		int type = -1;
		fscanf(fp,"%d", &type);
		//2，根据类型创建对象
		switch (type)
		{
		case ST_Line:
		{
			Line* s = (Line*)calloc(1, sizeof(Line));
			s->super.type = type;
			if (EOF == fscanf(fp, "%d %d %d %d %lu\n", &s->x1, &s->y1, &s->x2, &s->y2, &s->super.lineColor))
			{
				return;
			}
			ShapeSet_Add(g_shapes, s);
			break;
		}
		case ST_Rect:
		{
			Rect* s = (Rect*)calloc(1, sizeof(Rect));
			s->super.super.type = type;
			if (EOF == fscanf(fp, "%d %d %d %d %lu\n", &s->super.x1, &s->super.y1, &s->super.x2, &s->super.y2, &s->super.super.lineColor))
			{
				return;
			}
			ShapeSet_Add(g_shapes, s);
			break;
		}
		case ST_Ellipse:
			break;
		case ST_Graffiti:
		{
			Graffiti* s = (Graffiti*)calloc(1, sizeof(Graffiti));
			graf_init(s, RED);
			s->super.type = type;
			//读取点数量
			fscanf(fp, "%d", &s->size);
			//循环读取
			for (int i = 0; i < s->size; i++)
			{
				fscanf(fp, "%d %d ", &s->points[i].x, &s->points[i].y);
			}
			//读取颜色
			fscanf(fp, "%lu", &s->super.lineColor);
			ShapeSet_Add(g_shapes, s);
			break;
		}
		case ST_FiveStar:
			break;
		case ST_Max:
			break;
		default:
			break;
		}

	}

	fclose(fp);
}