﻿#include"Shape.h"
#include<stdio.h>
void shape_init(Shape* shape, int type, COLORREF c)
{
	shape->type = type;
	shape->lineColor = c;
}

void line_init(Line* pline, int x1, int y1, int x2, int y2, COLORREF c)
{
	shape_init(&pline->super, ST_Line, c);	//初始化父类
	pline->x1 = x1;
	pline->y1 = y1;
	pline->x2 = x2;
	pline->y2 = y2;
}

void line_draw(Line* pline)
{
	setlinecolor(pline->super.lineColor);
	line(pline->x1, pline->y1, pline->x2, pline->y2);
}

void line_write(Line* pline, FILE* fp)
{
	if (pline && fp)
	{
		//type x1 y1 x2 y2 color
		fprintf(fp, "%d %d %d %d %d %lu\n", pline->super.type, pline->x1, pline->y1, pline->x2, pline->y2, pline->super.lineColor);
	}
}

void rect_init(Rect* rect, int x1, int y1, int x2, int y2, COLORREF c)
{
	line_init(&rect->super, x1, y1, x2, y2, c);
	rect->super.super.type = ST_Rect;
}

void rect_draw(Rect* rect)
{
	setlinecolor(rect->super.super.lineColor);
	rectangle(rect->super.x1, rect->super.y1, rect->super.x2, rect->super.y2);
}

void rect_write(Rect* rect, FILE* fp)
{
	line_write(&rect->super, fp);
}

void graf_init(Graffiti* graf, COLORREF c)
{
	shape_init(&graf->super, ST_Graffiti, c);
	graf->capacity = 500;	//开始容量500
	graf->size = 0;
	graf->points = (POINT*)calloc(graf->capacity, sizeof(POINT));
	if (graf->points == NULL)
	{
		printf("[error %d]memory allocated failed\n", __LINE__);
	}
}

void graf_draw(Graffiti* graf)
{
	if (graf->points)
	{
		setlinecolor(graf->super.lineColor);
		polyline(graf->points, graf->size);
	}
}

void graf_addPoint(Graffiti* graf, int x, int y)
{
	//是否能插
	if (graf->size < graf->capacity)
	{
		graf->points[graf->size++] = { x,y };
	}
	//满了，需要扩容
	else if(graf->size == graf->capacity)
	{
		graf->capacity *= 2;	//每次扩容为本身的两倍
		POINT* newPoints = (POINT*)realloc(graf->points, graf->capacity);
		if (newPoints == NULL)
		{
			printf("[error %d]扩容失败\n", __LINE__);
		}
		else
		{
			graf->points = newPoints;
		}
	}
}

void graf_free(Graffiti* graf)
{
	free(graf->points);
	memset(graf, 0, sizeof(Graffiti));
}

void graf_write(Graffiti* graf, FILE* fp)
{
	if (!graf || !fp)
		return;
	//type PointCount
	fprintf(fp,"%d %d ", graf->super.type, graf->size);
	//points 很多个点，遍历
	for (int i = 0; i < graf->size; i++)
	{
		fprintf(fp,"%d %d ", graf->points[i].x, graf->points[i].y);
	}
	//color
	fprintf(fp, "%lu\n", graf->super.lineColor);
}
