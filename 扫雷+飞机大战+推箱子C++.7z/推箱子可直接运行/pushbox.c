﻿#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>
#include<conio.h>	//按键操作需要
/*
* 1,推箱子怎么做？有些什么东西？用什么存储？
*	空地		0
*	墙		1
*	目的地	2
*	箱子		3
*	玩家		4
*	目的地+箱子 5
*	目的地+玩家 6
* 用二维数组存储
* 2,动起来，移动玩家，移动箱子
* 3,关卡的切换
* 
*/

#define SPACE	0	//空地		
#define WALL	1	//墙		
#define	DEST	2	//目的地	
#define	BOX		3	//箱子		
#define	PLAYER	4	//玩家		

#define ROW 10
#define COL	10
//当前关卡
int curLevel = 0;
//定义地图
char map[3][ROW][COL] = 
{
	{
		{0,0,0,0,0,0,0,0,0,0},
		{0,0,0,1,1,1,0,0,0,0},
		{0,0,0,1,2,1,0,0,0,0},
		{0,0,0,1,3,1,1,1,1,0},
		{0,1,1,1,0,3,0,2,1,0},
		{0,1,2,3,4,0,1,1,1,0},
		{0,1,1,1,1,3,1,0,0,0},
		{0,0,0,0,1,2,1,0,0,0},
		{0,0,0,0,1,1,1,0,0,0},
		{0,0,0,0,0,0,0,0,0,0}
	},
	{
		{0,0,0,0,0,0,0,0,0,0},
		{0,0,1,1,0,0,1,1,0,0},
		{0,1,0,2,1,1,2,0,1,0},
		{1,0,0,0,0,0,0,0,0,1},
		{1,0,0,3,4,0,3,0,0,1},
		{0,1,0,0,3,3,0,0,1,0},
		{0,0,1,0,0,0,0,1,0,0},
		{0,0,0,1,2,2,1,0,0,0},
		{0,0,0,0,1,1,0,0,0,0},
		{0,0,0,0,0,0,0,0,0,0}
	},
	{
		{1,0,0,0,0,0,0,0,0,1},
		{1,1,0,1,1,1,1,0,1,1},
		{1,0,1,1,0,0,1,1,0,1},
		{1,0,0,0,0,0,0,0,0,1},
		{1,0,0,0,0,0,0,0,0,1},
		{1,0,0,0,0,0,0,0,0,1},
		{1,0,0,1,1,0,1,1,0,1},
		{1,0,1,0,0,0,0,0,0,1},
		{1,0,0,0,0,0,0,0,0,1},
		{1,1,1,1,1,1,1,1,1,1}
	},
};
//输出map[curLevel]
void show()
{
	for (int i = 0; i < ROW; i++)
	{
		for (int k = 0; k < COL; k++)
		{
			switch (map[curLevel][i][k])
			{
			case SPACE:
				printf("  ");
				break;
			case WALL:
				printf("▓ ");
				break;
			case DEST:
				printf("☆");
				break;
			case BOX:
				printf("□");
				break;
			case PLAYER:
				printf("♀");
				break;
			case DEST+BOX:		//箱子在目的地
				printf("★");
				break;
			case DEST+PLAYER:	//玩家在目的地
				printf("♂");
				break;
			}
			//if (map[curLevel][i][k] == SPACE)
			//{
			//	printf("  ");
			//}
			//else if (map[curLevel][i][k] == WALL)
			//{
			//	printf("墙");
			//}
			//else
			//{
			//	printf("%d ", map[curLevel][i][k]);
			//}
			
		}
		printf("\n");
	}
}
//移动
void move()
{
	//查找玩家所在的下标
	int r = -1, c = -1;	//记录玩家的下标
	for (int i = 0; i < ROW; i++)
	{
		for (int k = 0; k < COL; k++)
		{
			if (map[curLevel][i][k] == PLAYER || map[curLevel][i][k] == DEST + PLAYER)	//这里一定能够找到玩家吗？
			{
				r = i;
				c = k;
				goto endloop;
			}
		}
	}
endloop:
	if (r == -1 || c == -1)
		return;
	//怎么样获取按键 getchar() 输入之后需要按回车				
	//还有一个函数和getchar很像，但是不需要按回车 _getch()	必须包含头文件conio.h	
	switch (_getch())
	{
	case 'W':
	case 'w':
	case 72:
		//玩家的前面是空地或者目的地
		if (map[curLevel][r-1][c] == SPACE || map[curLevel][r-1][c] == DEST)
		{
			//1，把玩家移动到空地
			map[curLevel][r - 1][c] += PLAYER;
			//2，把玩家从原来的位置清除掉
			map[curLevel][r][c] -= PLAYER;
		}
		//玩家的前面是箱子
		else if(map[curLevel][r-1][c] == BOX)
		{
			//箱子的前面是空地或者是目的地
			if (map[curLevel][r - 2][c] == SPACE || map[curLevel][r-2][c] == DEST)
			{
				//1，把箱子移动到箱子前面
				map[curLevel][r - 2][c] += BOX;
				//2,把箱子从原来的位置清除
				map[curLevel][r - 1][c] -= BOX;
				//3，把玩家移动到原来的箱子位置
				map[curLevel][r - 1][c] += PLAYER;
				//4，把玩家从原来的位置清除掉
				map[curLevel][r][c] -= PLAYER;
			}
		}
		break;
	case 'S':
	case 's':
	case 80:
		//玩家的前面是空地或者目的地
		if (map[curLevel][r + 1][c] == SPACE || map[curLevel][r + 1][c] == DEST)
		{
			//1，把玩家移动到空地
			map[curLevel][r + 1][c] += PLAYER;
			//2，把玩家从原来的位置清除掉
			map[curLevel][r][c] -= PLAYER;
		}
		//玩家的前面是箱子
		else if (map[curLevel][r + 1][c] == BOX)
		{
			//箱子的前面是空地或者是目的地
			if (map[curLevel][r + 2][c] == SPACE || map[curLevel][r + 2][c] == DEST)
			{
				//1，把箱子移动到箱子前面
				map[curLevel][r + 2][c] += BOX;
				//2,把箱子从原来的位置清除
				map[curLevel][r + 1][c] -= BOX;
				//3，把玩家移动到原来的箱子位置
				map[curLevel][r + 1][c] += PLAYER;
				//4，把玩家从原来的位置清除掉
				map[curLevel][r][c] -= PLAYER;
			}
		}
		break;
	case 'A':
	case 'a':
	case 75:
		//玩家的前面是空地或者目的地
		if (map[curLevel][r][c - 1] == SPACE || map[curLevel][r][c - 1] == DEST)
		{
			//1，把玩家移动到空地
			map[curLevel][r][c - 1] += PLAYER;
			//2，把玩家从原来的位置清除掉
			map[curLevel][r][c] -= PLAYER;
		}
		//玩家的前面是箱子
		else if (map[curLevel][r][c - 1] == BOX)
		{
			//箱子的前面是空地或者是目的地
			if (map[curLevel][r][c - 2] == SPACE || map[curLevel][r][c - 2] == DEST)
			{
				//1，把箱子移动到箱子前面
				map[curLevel][r][c - 2] += BOX;
				//2,把箱子从原来的位置清除
				map[curLevel][r][c - 1] -= BOX;
				//3，把玩家移动到原来的箱子位置
				map[curLevel][r][c - 1] += PLAYER;
				//4，把玩家从原来的位置清除掉
				map[curLevel][r][c] -= PLAYER;
			}
		}
		break;
	case 'D':
	case 'd':
	case 77:
		//玩家的前面是空地或者目的地
		if (map[curLevel][r][c + 1] == SPACE || map[curLevel][r][c + 1] == DEST)
		{
			//1，把玩家移动到空地
			map[curLevel][r][c + 1] += PLAYER;
			//2，把玩家从原来的位置清除掉
			map[curLevel][r][c] -= PLAYER;
		}
		//玩家的前面是箱子
		else if (map[curLevel][r][c + 1] == BOX)
		{
			//箱子的前面是空地或者是目的地
			if (map[curLevel][r][c + 2] == SPACE || map[curLevel][r][c + 2] == DEST)
			{
				//1，把箱子移动到箱子前面
				map[curLevel][r][c + 2] += BOX;
				//2,把箱子从原来的位置清除
				map[curLevel][r][c + 1] -= BOX;
				//3，把玩家移动到原来的箱子位置
				map[curLevel][r][c + 1] += PLAYER;
				//4，把玩家从原来的位置清除掉
				map[curLevel][r][c] -= PLAYER;
			}
		}
		break;
	}
}
//神情况下才过关？如果地图上没有箱子就可以了，没有目的地
bool judge()
{
	for (int i = 0; i < ROW; i++)
	{
		for (int k = 0; k < COL; k++)
		{
			//三维数组
			if (map[curLevel][i][k] == BOX)
			{
				return false;
			}
		}
	}
	return true;
}

int main()
{
	while (true)
	{
		system("cls");	//清屏
		show();
		if (judge())
		{
			curLevel++;
		}

		//不断地检测键盘按键，不断地绘制  72 80 75 77 上 下 左 右
		move();
	}

	return 0;
}